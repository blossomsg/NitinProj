from distutils.core import setup

setup(
    name="NitinProj",
    version="0.1dev",
    packages=["createprojstructure", ],
    license="MIT",
    long_description=open("D:\\All_Projs\\NitinProj\\README.txt").read(),
)
